//Aluna: Raquel Barreto Miranda da Rosa
//Disciplina optativa de C++
//Jogo do campo minado
//Professor: Pedro Lara
//CEFET/RJ Campus Petropólis


// Os arquivos de cabeçalho
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
 
// Para utilizarmos o fprintf
#include <stdio.h>
#include <time.h>
#include <iostream>
#include <cstdlib>
using namespace std;
#define TLINHA2 16
#define TCOLUNA2 16
#define TLINHA1 8
#define TCOLUNA1 8

// Atributos da tela
const int LARGURA_TELA2 = 560;
const int ALTURA_TELA2 = 560;

int Tcoluna;
int Tlinha;
 

class quadrado{
private:
	bool bomba;
	int numBomba;
	bool bandeira;
	bool aberto;
public:
	quadrado(){
		bomba = 0;
		numBomba = 0;
		bandeira = 0;
		aberto = 0;
	}
	void setBomba(bool bomb){
		bomba = bomb;
	}
	bool getBomba(){
		return bomba;
	}
	void setNumBomba(int num){
		numBomba = num;
	}
	void setBandeira(bool flag){
		bandeira = flag;
	}
	int getnumBomba(){
		return numBomba;
	}
	bool getBandeira(){
		return bandeira;
	}
	bool getAberto(){
		return aberto;
	}
	void setAberto(bool aux){
		aberto = aux;
	}

};

class Tabuleiro{
private:
	quadrado **tabuleiro;
	int numBomba;
public:
	Tabuleiro(int numBomba): numBomba(numBomba){
		tabuleiro = (quadrado**)malloc(Tlinha * sizeof(quadrado*));
		for(int i=0; i<Tlinha; i++){
			tabuleiro[i] = (quadrado*) malloc (Tcoluna * sizeof(quadrado));
		}
		//imprime();
		setbombas();
		
		for(int i = 0; i < Tlinha; i++){
			for(int j = 0; j < Tcoluna; j ++){
				tabuleiro[i][j].setNumBomba(numBombas(i, j));	
			}				
		}

	}
	int getNumBomba(){
		return numBomba;
	}
	int numBombas(int i, int j){
		int num = 0;
		if(i-1>=0 && j-1>=0)
			num += tabuleiro[i-1][j-1].getBomba();
		if(i-1>=0)
			num += tabuleiro[i-1][j].getBomba();
		if(i-1>= 0 && j+1< Tcoluna)
			num += tabuleiro[i-1][j+1].getBomba();
		if(j-1>=0)
			num += tabuleiro[i][j-1].getBomba();
		if(j+1< Tcoluna)
			num += tabuleiro[i][j+1].getBomba();
		if(i+1< Tlinha && j-1>=0)
			num += tabuleiro[i+1][j-1].getBomba();
		if(i+1< Tlinha)
			num += tabuleiro[i+1][j].getBomba();
		if(i+1 < Tlinha && j < Tcoluna)
			num += tabuleiro[i+1][j+1].getBomba();
		return num;
	}
	void setbombas(){
		int i,j,aux;
		aux = numBomba;
		while(aux){
			i = rand()%Tlinha;
			j = rand()%Tcoluna;
			if(!tabuleiro[i][j].getBomba()){
				tabuleiro[i][j].setBomba(1); 
				aux--;
			}
		}		
	}

	void imprime(){
		int i, j;
		for(i = 0; i < Tlinha; i++){
			for(j = 0; j < Tcoluna; j ++){
				if(tabuleiro[i][j].getBomba() == 1)
					cout << "* ";
				else
					cout << numBombas(i, j) << ' ';	
			}
			    cout << endl;				
		}
		cout << endl;
	}
	quadrado retornaq(int i, int j){
		return(tabuleiro[i][j]);
	}
	void setBombat(int i, int j, bool bomb){
		tabuleiro[i][j].setBomba(bomb);
	}
	bool getBombat(int i, int j){
		return tabuleiro[i][j].getBomba();
	}
	void setNumBombat(int i, int j, int num){
		tabuleiro[i][j].setNumBomba(num);
	}
	void setBandeirat(int i, int j, bool flag){
		tabuleiro[i][j].setBandeira(flag);
	}
	int getnumBombat(int i, int j){
		return tabuleiro[i][j].getnumBomba();
	}
	bool getBandeirat(int i, int j){
		return tabuleiro[i][j].getBandeira();
	}
	bool getAbertot(int i, int j){
		return tabuleiro[i][j].getAberto();
	}
	void setAbertot(int i, int j, bool aux){
		tabuleiro[i][j].setAberto(aux);
	}

};
int verificaGanhou(Tabuleiro tab){
	int contaAbertos=0;
	for(int i = 0; i<Tlinha;i++){
		for(int j = 0; j<Tcoluna; j++){
			if(tab.getAbertot(i,j))
				contaAbertos++;
		}
	}
	//cout<< contaAbertos<< endl;
	//cout<<tab.getNumBomba()<<endl;	
	
	if(contaAbertos == ((Tlinha*Tcoluna)-tab.getNumBomba()) )
			return 1;
	return 0;

}
void Pintar(Tabuleiro tab1, int x, int y,int i, int j, ALLEGRO_BITMAP *limpa, ALLEGRO_BITMAP *a1,ALLEGRO_BITMAP *a2,ALLEGRO_BITMAP *a3,ALLEGRO_BITMAP *a4,ALLEGRO_BITMAP *a5,ALLEGRO_BITMAP *a6,ALLEGRO_BITMAP *a7,ALLEGRO_BITMAP *a8){
	if( (x>=0 && x<Tlinha) && (y>=0 && y<Tcoluna) ){
		if(!tab1.getAbertot(x,y) && !tab1.getBombat(x,y)) {

			if(tab1.getnumBombat(x, y) == 0){
				//al_draw_bitmap(limpa, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
				//al_flip_display();
				//tab1.setAbertot(i, j, 1);
				
				al_draw_bitmap(limpa, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);

				Pintar(tab1,x+1,y,i+35,j,limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x+1,y+1,i+35,j+35, limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x-1,y,i-35,j,limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x+1,y-1,i+35,j-35,limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x,y+1,i,j+35, limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x-1,y+1,i-35,j+35, limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x,y-1,i,j-35, limpa,a1,a2,a3,a4,a5,a6,a7,a8);
				Pintar(tab1,x-1,y-1,i-35,j-35, limpa,a1,a2,a3,a4,a5,a6,a7,a8);
			}
			else if(tab1.getnumBombat(x, y) == 1){
				al_draw_bitmap(a1, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 2){
				al_draw_bitmap(a2, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 3){
				al_draw_bitmap(a3, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 4){
				al_draw_bitmap(a4, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 5){
				al_draw_bitmap(a5, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 6){
				al_draw_bitmap(a6, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 7){
				al_draw_bitmap(a7, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}
			else if(tab1.getnumBombat(x, y) == 8){
				al_draw_bitmap(a1, (i/35)*35 , (j/35)*35, 0);
				al_flip_display();
				tab1.setAbertot(x, y, 1);
			}



		}
	}
} 
int main(void)
{
	int i, j, k , l, block=0;
	srand((unsigned)time(0));
	Tcoluna = TCOLUNA2;
	Tlinha = TLINHA2;
	Tabuleiro tab1(40);

	//allegro_mouse();
    ALLEGRO_DISPLAY *janela = NULL;
    ALLEGRO_BITMAP *imagem = NULL;
    ALLEGRO_BITMAP *limpa = NULL;
	ALLEGRO_BITMAP *a1 = NULL;
	ALLEGRO_BITMAP *a2 = NULL;
	ALLEGRO_BITMAP *a3 = NULL;
	ALLEGRO_BITMAP *a4 = NULL;
	ALLEGRO_BITMAP *a5 = NULL;
	ALLEGRO_BITMAP *a6 = NULL;
	ALLEGRO_BITMAP *a7 = NULL;
	ALLEGRO_BITMAP *a8 = NULL;
	ALLEGRO_BITMAP *principal = NULL;
	ALLEGRO_BITMAP *ganhou = NULL;
	ALLEGRO_BITMAP *bandeira = NULL;
	ALLEGRO_BITMAP *bomba = NULL;
    ALLEGRO_EVENT_QUEUE *fila_eventos = NULL;
	ALLEGRO_BITMAP *go =NULL;
 

    if (!al_init())
    {
        fprintf(stderr, "Falha ao inicializar a Allegro.\n");
        return -1;
    }
 
    if (!al_init_image_addon())
    {
        fprintf(stderr, "Falha ao inicializar add-on allegro_image.\n");
        return -1;
    }
 
    janela = al_create_display(Tlinha*35, Tcoluna*35);
    if (!janela)
    {
        fprintf(stderr, "Falha ao criar janela.\n");
        return -1;
    }
	al_set_window_title(janela, "Campo Minado Pink da Kekel"); 
    imagem = al_load_bitmap("b3.png");
    a1 = al_load_bitmap("1.png");
    a2 = al_load_bitmap("2.png");
    a3 = al_load_bitmap("3.png");
    a4 = al_load_bitmap("4.png");
    a5 = al_load_bitmap("5.png");
    a6 = al_load_bitmap("6.png");
    a7 = al_load_bitmap("7.png");
    a8 = al_load_bitmap("8.png");
    go = al_load_bitmap("go.png");
	limpa = al_load_bitmap("a.jpg");
    principal = al_load_bitmap("principal.png");
	ganhou = al_load_bitmap("ganhou.png");
    bandeira = al_load_bitmap("bandeira.png");
    bomba = al_load_bitmap("bomba.png");
    if (!imagem)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!limpa)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!bandeira)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!bomba)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a1)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a2)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a3)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a4)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a5)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a6)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    } 
    if (!a7)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    if (!a8)
    {
        fprintf(stderr, "Falha ao carregar o arquivo de imagem.\n");
        al_destroy_display(janela);
        return -1;
    }
    fila_eventos = al_create_event_queue();
    if (!fila_eventos)
    {
        fprintf(stderr, "Falha ao criar fila de eventos.\n");
        al_destroy_display(janela);
        return -1;
    }
 
    al_register_event_source(fila_eventos, al_get_display_event_source(janela));


	if(!al_install_mouse()){
		fprintf(stderr, "Falha ao inicializar o mouse. \n");
		al_destroy_display(janela);
		return -1;
	}

 
	for(int i=0;i<=(Tlinha*35);i+=35){
		for(int j=0;j<=(Tcoluna*35);j+=35){
    		al_draw_bitmap(imagem, i, j, 0);
		}
	}
	al_flip_display();
	
	    
	al_register_event_source(fila_eventos, al_get_mouse_event_source());
    while (1)
    {
        ALLEGRO_EVENT evento;
 
        al_wait_for_event(fila_eventos, &evento);

        if (evento.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
        {
            break;
        }
		if(evento.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP){
			i =((evento.mouse.x/35) % Tlinha);
			j = ((evento.mouse.y/35)%Tcoluna);
			if(!tab1.getAbertot(i,j) && !block){
				if(evento.mouse.button & 1 && !tab1.getBandeirat(i, j) ){
					if(tab1.getBombat(i,j)){
						al_draw_bitmap(bomba, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						for(l=0;l<Tlinha;l++){
							for(k=0;k<Tcoluna; k++){
								if(tab1.getBombat(l,k)){
									al_draw_bitmap(bomba, l*35 , k*35, 0);
									al_flip_display();
								}
							}
						}
						block = 1;
						al_draw_bitmap(go,30, 70, 0);
						al_flip_display();
						
						
					}
					else if(tab1.getnumBombat(i, j) == 0){
						//al_draw_bitmap(limpa, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						//al_flip_display();
						//tab1.setAbertot(i, j, 1);
 						Pintar(tab1, i, j,evento.mouse.x,evento.mouse.y, limpa,a1,a2,a3,a4,a5,a6,a7,a8);

					}
					else if(tab1.getnumBombat(i, j) == 1){
						al_draw_bitmap(a1, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
					else if(tab1.getnumBombat(i, j) == 2){
						al_draw_bitmap(a2, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
					else if(tab1.getnumBombat(i, j) == 3){
						al_draw_bitmap(a3, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);


					}
					else if(tab1.getnumBombat(i, j) == 4){
						al_draw_bitmap(a4, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
					else if(tab1.getnumBombat(i, j) == 5){
						al_draw_bitmap(a5, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
					else if(tab1.getnumBombat(i, j) == 6){
						al_draw_bitmap(a6, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
					else if(tab1.getnumBombat(i, j) == 7){
						al_draw_bitmap(a7, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);
			
					}
					else if(tab1.getnumBombat(i, j) == 8){
						al_draw_bitmap(a1, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setAbertot(i, j, 1);

					}
				}
				else{
					if(tab1.getBandeirat(i, j)){
						al_draw_bitmap(imagem,(evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setBandeirat(i, j,0);
						
					}
					else{
						al_draw_bitmap(bandeira, (evento.mouse.x/35)*35 , (evento.mouse.y/35)*35, 0);
						al_flip_display();
						tab1.setBandeirat(i, j,1);
						
					}

				}
			}


		}
		if(verificaGanhou(tab1) == 1){
			al_draw_bitmap(ganhou, 15 , 70, 0);
			al_flip_display();
		}
 
       // al_flip_display();
    }
 
    al_destroy_display(janela);
    al_destroy_event_queue(fila_eventos);
 
    return 0;
}
